# Create: To Do
Description: Create a new todo

Endpoint: 
POST: https://h4sk8blscl.execute-api.us-east-1.amazonaws.com/dev/todos

Body:
{
  "todo": [
    "todo 1",
    "todo 2",
    "todo 3"
  ]
}


# Delete: To Do
Description: Delete a todo

Endpoint: 
DELETE: https://h4sk8blscl.execute-api.us-east-1.amazonaws.com/dev/todos?id=13

QueryStringParameters: 
id = To Do ID

# List: To Do
Description: Returns all To Do

Endpoint: 
GET: https://h4sk8blscl.execute-api.us-east-1.amazonaws.com/dev/todos


# UPDATE: To Do
Description: Update a To Do.

Endpoint: 
PUT: https://h4sk8blscl.execute-api.us-east-1.amazonaws.com/dev/todos?id=12

QueryStringParameters: 
id = To Do ID

Body:
{
  "todo": "free text"
}




